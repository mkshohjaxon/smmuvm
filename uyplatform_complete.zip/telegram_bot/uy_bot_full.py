import os, logging, requests, json, tempfile
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler, ConversationHandler, ContextTypes

API_BASE = os.environ.get('API_BASE','http://localhost:8000')
BOT_TOKEN = os.environ.get('BOT_TOKEN')
ADMIN_ID = int(os.environ.get('ADMIN_ID','0'))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

(TITLE, DESC, PRICE, LOCATION, PHOTOS) = range(5)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = f"💎 Salom, {user.first_name}!\nUy-Oldi Sotdi botiga xush kelibsiz."
    kb = [[InlineKeyboardButton("➕ E'lon joylash", callback_data='post')],[InlineKeyboardButton("🔎 E'lonlarni ko'rish", callback_data='browse')],[InlineKeyboardButton('👤 Profil', callback_data='profile')]]
    await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(kb))

async def post_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('Sarlavhani kiriting', reply_markup=ReplyKeyboardRemove())
    return TITLE

async def post_title(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['prop']={'title': update.message.text}; await update.message.reply_text('Ta\'rif'); return DESC
async def post_desc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['prop']['description']=update.message.text; await update.message.reply_text('Narx (raqam)'); return PRICE
async def post_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['prop']['price']=float(update.message.text.replace(' ','').replace(',','')); kb=ReplyKeyboardMarkup([[KeyboardButton('📍 Joylashuvni yuborish', request_location=True)],['Manzilni yozish']], resize_keyboard=True); await update.message.reply_text('Manzil yuboring yoki joylashuvni ulashing', reply_markup=kb); return LOCATION
async def post_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    p=context.user_data['prop']
    if update.message.location:
        loc=update.message.location; p['lat']=loc.latitude; p['lon']=loc.longitude; p['address']=f"{loc.latitude:.5f},{loc.longitude:.5f}"
    else:
        p['address']=update.message.text
    p['photos']=[]; await update.message.reply_text("Rasmlarni yuboring yoki 'Tugallandi' deb yozing", reply_markup=ReplyKeyboardRemove()); return PHOTOS

async def post_photos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.photo:
        fid = update.message.photo[-1].file_id; context.user_data['prop'].setdefault('photos',[]).append(fid); await update.message.reply_text(f'Rasm qabul qilindi. Jami: {len(context.user_data["prop"]["photos"])}'); return PHOTOS
    if update.message.text and update.message.text.lower() in ('tugallandi','done'):
        prop=context.user_data['prop']; files=[]; tmpfiles=[]
        for fid in prop.get('photos',[]):
            f = await context.bot.get_file(fid)
            tf = tempfile.NamedTemporaryFile(delete=False, suffix='.jpg'); await f.download_to_drive(tf.name); tmpfiles.append(tf.name); files.append(('files', open(tf.name,'rb')))
        data = {'title': prop['title'], 'description': prop['description'], 'price': str(prop['price']), 'address': prop.get('address',''), 'telegram_id': str(update.effective_user.id)}
        r = requests.post(f"{API_BASE}/properties/", data=data, files=files)
        for t in tmpfiles:
            try: os.remove(t)
            except: pass
        if r.status_code in (200,201):
            j=r.json(); await update.message.reply_text('E\'lon yuborildi. Admin tasdiqlangach ko\'rinadi.'); try: await context.bot.send_message(ADMIN_ID, f"Yangi e'lon ID {j.get('id')} tasdiqlashni kutmoqda.") 
            except Exception as e: logger.exception('notify admin') 
        else:
            await update.message.reply_text('Serverga yuborishda xatolik') 
        return ConversationHandler.END
    await update.message.reply_text("Rasm yuboring yoki 'Tugallandi' deb yozing"); return PHOTOS

async def browse_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    res = requests.get(f"{API_BASE}/properties"); if res.status_code==200: items=res.json().get('items',[]); text='E\'lonlar:\n'; 
    for it in items[:10]: text+=f"ID {it['id']}: {it['title']} — {int(it.get('price') or 0)} {it.get('currency','UZS')}\n"
    await update.callback_query.message.reply_text(text)

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    conv = ConversationHandler(entry_points=[CommandHandler('post', post_start)], states={ TITLE:[MessageHandler(filters.TEXT & ~filters.COMMAND, post_title)], DESC:[MessageHandler(filters.TEXT & ~filters.COMMAND, post_desc)], PRICE:[MessageHandler(filters.TEXT & ~filters.COMMAND, post_price)], LOCATION:[MessageHandler((filters.LOCATION | filters.TEXT) & ~filters.COMMAND, post_location)], PHOTOS:[MessageHandler((filters.PHOTO | filters.TEXT) & ~filters.COMMAND, post_photos)] }, fallbacks=[CommandHandler('cancel', lambda u,c: c.bot.send_message(u.effective_user.id,'Bekor qilindi.'))], allow_reentry=True)
    app.add_handler(CommandHandler('start', start)); app.add_handler(conv); app.add_handler(CallbackQueryHandler(browse_cb, pattern='^browse$'))
    print('Bot started'); app.run_polling()

if __name__=='__main__': main()
