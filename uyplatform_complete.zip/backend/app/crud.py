import json
from sqlalchemy.orm import Session
from . import models, schemas
from datetime import datetime, timedelta

def create_user_if_not_exists(db: Session, telegram_id: int, username: str=None):
    u = db.query(models.User).filter(models.User.telegram_id==telegram_id).first()
    if u:
        return u
    u = models.User(telegram_id=telegram_id, username=username)
    db.add(u); db.commit(); db.refresh(u)
    return u

def create_property(db: Session, user_id: int, p: schemas.PropertyCreate, approved: bool=False):
    prop = models.Property(
        user_id = user_id,
        title = p.title,
        description = p.description,
        price = p.price,
        currency = p.currency,
        address = p.address,
        lat = p.lat,
        lon = p.lon,
        photos = json.dumps(p.photos or []),
        approved = approved
    )
    db.add(prop); db.commit(); db.refresh(prop)
    return prop

def list_properties(db: Session, limit:int=100, offset:int=0, approved:bool=True, q:str=None, min_price:float=None, max_price:float=None, city:str=None, ptype:str=None, boosted_only:bool=False):
    query = db.query(models.Property)
    if approved is not None:
        query = query.filter(models.Property.approved == approved)
    if boosted_only:
        query = query.filter(models.Property.is_boosted==True, models.Property.boost_until > datetime.utcnow())
    if q:
        query = query.filter(models.Property.title.ilike(f"%{q}%") | models.Property.address.ilike(f"%{q}%"))
    if min_price is not None:
        query = query.filter(models.Property.price >= min_price)
    if max_price is not None:
        query = query.filter(models.Property.price <= max_price)
    # ordering: boosted first, then recent
    query = query.order_by(models.Property.is_boosted.desc(), models.Property.boost_until.desc(), models.Property.created_ts.desc())
    items = query.offset(offset).limit(limit).all()
    return items

def get_property(db: Session, prop_id:int):
    return db.query(models.Property).filter(models.Property.id==prop_id).first()

def approve_property(db: Session, prop_id:int, approve:bool=True):
    p = get_property(db, prop_id)
    if not p: return None
    p.approved = approve
    db.commit(); db.refresh(p)
    return p

def set_boost(db: Session, prop_id:int, days:int):
    p = get_property(db, prop_id)
    if not p: return None
    p.is_boosted = True
    p.boost_until = datetime.utcnow() + timedelta(days=days)
    db.commit(); db.refresh(p)
    return p

def remove_property(db: Session, prop_id:int):
    p = get_property(db, prop_id)
    if not p: return False
    db.delete(p); db.commit(); return True

def list_user_props(db: Session, user_id:int):
    return db.query(models.Property).filter(models.Property.user_id==user_id).order_by(models.Property.created_ts.desc()).all()

def update_property(db: Session, prop_id:int, payload:dict):
    p = get_property(db, prop_id)
    if not p: return None
    for k,v in payload.items():
        setattr(p, k, v)
    db.commit(); db.refresh(p); return p
