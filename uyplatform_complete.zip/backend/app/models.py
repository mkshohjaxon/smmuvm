from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.sql import func
from .database import Base

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(Integer, unique=True, nullable=True, index=True)
    username = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    created_ts = Column(DateTime(timezone=True), server_default=func.now())

class Property(Base):
    __tablename__ = 'properties'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=True, index=True)
    title = Column(String, nullable=False, index=True)
    description = Column(Text, nullable=True)
    price = Column(Float, nullable=True)
    currency = Column(String, default='UZS')
    address = Column(String, nullable=True, index=True)
    lat = Column(Float, nullable=True)
    lon = Column(Float, nullable=True)
    photos = Column(Text, nullable=True)  # JSON list
    approved = Column(Boolean, default=False, index=True)
    is_boosted = Column(Boolean, default=False, index=True)
    boost_until = Column(DateTime, nullable=True, index=True)
    created_ts = Column(DateTime(timezone=True), server_default=func.now())
