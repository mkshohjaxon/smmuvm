from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import init_db
from .routers import properties, admin, payments
from .config import settings
from fastapi.staticfiles import StaticFiles
import os
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from .database import SessionLocal
from .crud import set_boost

app = FastAPI(title=settings.APP_NAME)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.on_event('startup')
def on_startup():
    init_db()
    # start scheduler for notifications / boost expiry check
    scheduler = BackgroundScheduler()
    scheduler.add_job(check_boosts, 'interval', seconds=settings.NOTIFY_INTERVAL_SECONDS, id='boost_check', replace_existing=True)
    scheduler.start()

app.include_router(properties.router, prefix='/properties', tags=['properties'])
app.include_router(admin.router, prefix='/admin', tags=['admin'])
app.include_router(payments.router, prefix='/payments', tags=['payments'])

BASE_DIR = os.path.dirname(__file__)
app.mount('/static', StaticFiles(directory=os.path.join(BASE_DIR, 'static')), name='static')

def check_boosts():
    # This function scans boosts and could notify users via Telegram if boost expired.
    try:
        db: Session = SessionLocal()
        from . import models
        now = datetime.now(timezone.utc)
        expired = db.query(models.Property).filter(models.Property.is_boosted==True, models.Property.boost_until<=now).all()
        for p in expired:
            p.is_boosted = False
            db.add(p)
            # Here you would notify user via Telegram bot (call bot API or queue message)
            print(f"[BOOST EXPIRED] property id={p.id}")  # placeholder
        db.commit()
    except Exception as e:
        print('check_boosts error', e)
    finally:
        try: db.close()
        except: pass
