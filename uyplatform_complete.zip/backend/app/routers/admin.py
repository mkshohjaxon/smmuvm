from fastapi import APIRouter, Depends, Form, HTTPException
from sqlalchemy.orm import Session
from .. import deps, crud, models
from datetime import datetime
router = APIRouter()

@router.put('/approve/{prop_id}')
def approve(prop_id:int, approve: bool = Form(True), db: Session = Depends(deps.get_db)):
    p = crud.approve_property(db, prop_id, approve=approve)
    if not p: raise HTTPException(404, 'Not found')
    return {'ok': True, 'id': p.id, 'approved': p.approved}

@router.get('/stats')
def stats(db: Session = Depends(deps.get_db)):
    total = db.query(models.Property).count()
    approved = db.query(models.Property).filter(models.Property.approved==True).count()
    boosted = db.query(models.Property).filter(models.Property.is_boosted==True).count()
    users = db.query(models.User).count()
    return {'total': total, 'approved': approved, 'boosted': boosted, 'users': users}
