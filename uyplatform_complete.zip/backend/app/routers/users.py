from fastapi import APIRouter, Depends, HTTPException, Form
from sqlalchemy.orm import Session
from .. import deps, crud
router = APIRouter()

@router.get('/{telegram_id}/properties')
def my_props(telegram_id: int, db: Session = Depends(deps.get_db)):
    rows = crud.list_user_props(db, None) if False else crud.list_user_props(db, None)  # placeholder, we expect telegram_id -> user mapping in real app
    # For demo, return all properties where user_id is not null and user.telegram_id matches
    return {'items': []}
