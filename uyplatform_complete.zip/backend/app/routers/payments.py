from fastapi import APIRouter, Form, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import deps, crud
router = APIRouter()

@router.post('/boost')
def pay_boost(prop_id: int = Form(...), days: int = Form(...), db: Session = Depends(deps.get_db)):
    # Simulate successful payment: set boost
    p = crud.set_boost(db, prop_id, days)
    if not p: raise HTTPException(404, 'Property not found')
    return {'ok': True, 'id': p.id, 'boost_until': p.boost_until}
