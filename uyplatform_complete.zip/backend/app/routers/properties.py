from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from typing import List, Optional
from sqlalchemy.orm import Session
from .. import schemas, crud, deps
import os, uuid, json

router = APIRouter()

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, 'static', 'uploads')
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.get('/')
def list_props(q: Optional[str]=None, approved: Optional[bool]=True, min_price: Optional[float]=None, max_price: Optional[float]=None, city: Optional[str]=None, boosted: Optional[bool]=False, limit:int=100, offset:int=0, db: Session=Depends(deps.get_db)):
    items = crud.list_properties(db, limit=limit, offset=offset, approved=approved, q=q, min_price=min_price, max_price=max_price, city=city, boosted_only=boosted)
    out = []
    for it in items:
        out.append({
            'id': it.id, 'title': it.title, 'description': it.description, 'price': it.price, 'currency': it.currency, 'address': it.address,
            'lat': it.lat, 'lon': it.lon, 'photos': json.loads(it.photos) if it.photos else [], 'approved': it.approved, 'is_boosted': it.is_boosted, 'boost_until': it.boost_until, 'created_ts': it.created_ts
        })
    return {'items': out, 'total': len(out)}

@router.get('/{prop_id}')
def get_prop(prop_id:int, db: Session=Depends(deps.get_db)):
    p = crud.get_property(db, prop_id)
    if not p: raise HTTPException(404, 'Not found')
    return {'id': p.id, 'title': p.title, 'description': p.description, 'price': p.price, 'currency': p.currency, 'address': p.address, 'lat': p.lat, 'lon': p.lon, 'photos': json.loads(p.photos) if p.photos else [], 'approved': p.approved, 'is_boosted': p.is_boosted, 'boost_until': p.boost_until, 'created_ts': p.created_ts}

@router.post('/', status_code=201)
def create_prop(title: str = Form(...), description: str = Form(''), price: float = Form(0.0), currency: str = Form('UZS'), address: str = Form(''), lat: Optional[float] = Form(None), lon: Optional[float] = Form(None), files: Optional[List[UploadFile]] = File(None), telegram_id: Optional[int] = Form(None), db: Session=Depends(deps.get_db)):
    photos = []
    if files:
        for f in files:
            ext = os.path.splitext(f.filename)[1] or '.jpg'
            name = f"{uuid.uuid4().hex}{ext}"
            path = os.path.join(UPLOAD_DIR, name)
            with open(path, 'wb') as fh:
                fh.write(f.file.read())
            photos.append(f"/static/uploads/{name}")
    from ..schemas import PropertyCreate
    payload = PropertyCreate(title=title, description=description, price=price, currency=currency, address=address, lat=lat, lon=lon, photos=photos)
    user_id = None
    if telegram_id:
        # ensure user exists
        from ..crud import create_user_if_not_exists
        u = create_user_if_not_exists(db, telegram_id, None)
        user_id = u.id
    prop = crud.create_property(db, user_id=user_id, p=payload, approved=False)
    return {'id': prop.id, 'created': True}

@router.delete('/{prop_id}')
def delete_prop(prop_id:int, db: Session=Depends(deps.get_db)):
    ok = crud.remove_property(db, prop_id)
    if not ok: raise HTTPException(404, 'Not found')
    return {'ok': True}

@router.put('/{prop_id}')
def update_prop(prop_id:int, title: Optional[str] = Form(None), description: Optional[str]=Form(None), price: Optional[float]=Form(None), address: Optional[str]=Form(None), db: Session=Depends(deps.get_db)):
    payload = {}
    if title is not None: payload['title'] = title
    if description is not None: payload['description'] = description
    if price is not None: payload['price'] = price
    if address is not None: payload['address'] = address
    p = crud.update_property(db, prop_id, payload)
    if not p: raise HTTPException(404, 'Not found')
    return {'ok': True, 'id': p.id}
