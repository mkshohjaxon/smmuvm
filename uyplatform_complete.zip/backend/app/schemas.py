from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class PropertyCreate(BaseModel):
    title: str
    description: Optional[str] = ''
    price: Optional[float] = 0.0
    currency: Optional[str] = 'UZS'
    address: Optional[str] = ''
    lat: Optional[float] = None
    lon: Optional[float] = None
    photos: Optional[List[str]] = []

class PropertyOut(BaseModel):
    id: int
    title: str
    description: Optional[str]
    price: Optional[float]
    currency: Optional[str]
    address: Optional[str]
    lat: Optional[float]
    lon: Optional[float]
    photos: List[str] = []
    approved: bool
    is_boosted: bool
    boost_until: Optional[datetime]
    created_ts: datetime
    class Config:
        orm_mode = True

class UserCreate(BaseModel):
    telegram_id: Optional[int]
    username: Optional[str]

class BoostRequest(BaseModel):
    days: int
    prop_id: int
