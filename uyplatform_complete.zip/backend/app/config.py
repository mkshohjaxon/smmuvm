from pydantic import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str = "Uy-Oldi Sotdi API"
    DATABASE_URL: str = "sqlite:///./uyplatform.db"
    STATIC_DIR: str = "static/uploads"
    ADMIN_TELEGRAM_ID: int = 0
    TELEGRAM_BOT_TOKEN: str = ""
    NOTIFY_INTERVAL_SECONDS: int = 60  # check boosts every minute for demo

    class Config:
        env_file = ".env"

settings = Settings()
