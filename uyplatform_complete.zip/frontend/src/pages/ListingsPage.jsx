import React, {useEffect, useState} from 'react'; import API from '../api'; import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';

export default function ListingsPage(){ const [items,setItems]=useState([]); const [q,setQ]=useState(''); const [minP,setMinP]=useState(''); const [maxP,setMaxP]=useState(''); useEffect(()=>{ fetchList() }, []);
  async function fetchList(){ const res = await API.get('/properties', { params: { q, min_price: minP||undefined, max_price: maxP||undefined } }); setItems(res.data.items||[]); }
  return (<div style={{display:'flex',height:'100vh'}}>
    <div style={{width:360,overflow:'auto',borderRight:'1px solid #eee',padding:12}}>
      <h2>Uy-Oldi Sotdi</h2>
      <a href="/add.html" style={{display:'inline-block',padding:8,background:'#10b981',color:'#fff',borderRadius:6,textDecoration:'none'}}>Qo'shish</a>
      <div style={{marginTop:12}}>
        <div><input placeholder='Kalit so`z' value={q} onChange={e=>setQ(e.target.value)}/> <button onClick={fetchList}>Qidirish</button></div>
        <div style={{marginTop:8}}>Min: <input value={minP} onChange={e=>setMinP(e.target.value)}/> Max: <input value={maxP} onChange={e=>setMaxP(e.target.value)}/> </div>
        {items.map(it=>(<div key={it.id} style={{background:'#fff',padding:8,marginBottom:10,borderRadius:8}}><div style={{fontWeight:700}}>{it.title}</div><div style={{color:'#666'}}>{it.address}</div><div style={{fontWeight:800}}>{it.price} {it.currency}</div><a href={'/property.html?id='+it.id}>Batafsil</a></div>))}
      </div>
    </div>
    <div style={{flex:1}}>
      <MapContainer center={[41.311081,69.240562]} zoom={12} style={{height:'100%',width:'100%'}}>
        <TileLayer url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'/>
        {items.map(it=> it.lat && it.lon ? (<Marker key={it.id} position={[it.lat,it.lon]}><Popup><div style={{width:200}}><b>{it.title}</b><br/>{it.address}<br/>{it.price} {it.currency}</div></Popup></Marker>) : null)}
      </MapContainer>
    </div>
  </div>) }
