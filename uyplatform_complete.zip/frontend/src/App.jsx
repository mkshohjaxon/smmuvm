import React from 'react'; import Listings from './pages/ListingsPage'; export default function App(){ return <Listings/> }
