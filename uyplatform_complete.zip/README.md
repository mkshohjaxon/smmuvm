Uy-Oldi Sotdi - Complete Starter (dev)

Folders:
- backend/: FastAPI app. Run: 
    cd backend
    pip install -r requirements.txt
    uvicorn app.main:app --reload --port 8000

- frontend/: simple Vite React. Run:
    cd frontend
    npm install
    npm run dev  # opens at http://localhost:5173

- telegram_bot/: run bot script (set BOT_TOKEN and ADMIN_ID env vars)

Notes:
- This starter includes boost endpoint, simulated payments, filters, user CRUD placeholders, admin stats, and a background job that prints expired boosts.
- For production, configure database, secrets, and real payment provider.
